### Checklist
- [ ] Pull request details were added to CHANGELOG.md.
- [ ] Documentation was updated (if required).
- [ ] `parameter_meta` was added/updated (if required).
